/* 
 * @author: Lebeko Poulo
 * @ Date: 26/08/2024
 */

public class Main {
    public static void main(String[] args) {
        ATM atm = new ATM();
        atm.start();
    }
}
