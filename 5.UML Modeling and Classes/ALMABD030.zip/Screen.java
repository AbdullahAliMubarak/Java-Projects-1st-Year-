/* 
 * @author: Lebeko Poulo
 * @ Date: 26/08/2024
 */

public class Screen {
    public void displayMessage(String message) {
        System.out.println(message);
    }
}
