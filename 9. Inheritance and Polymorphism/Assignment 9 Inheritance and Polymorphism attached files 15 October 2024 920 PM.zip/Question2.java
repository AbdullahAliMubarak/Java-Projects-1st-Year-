/*
 A8 Q2 Driver class.
*/

class Question2
{
   public static void main ( String args [] )
   {
      (new VectorGraphics (20, 20, 100)).run(args[0]);
   }
}
